from django.contrib.auth.models import User
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib import messages
from django.contrib.auth import logout
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator  # for Class Based Views
from django.http import HttpResponse
from datetime import datetime
import decimal
from store.models import Address, Cart, Category, Order, Product, Post  # Ensure this import covers your models
from .forms import RegistrationForm, AddressForm

# Logout View
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return render(request, 'store/logout.html')  # Redirects to logout confirmation page


# Home View
def home(request):
    categories = Category.objects.filter(is_active=True, is_featured=True)[:3]
    products = Product.objects.filter(is_active=True, is_featured=True)[:8]
    context = {
        'categories': categories,
        'products': products,
    }
    return render(request, 'store/index.html', context)

# Blog View
def blog_view(request):
    return render(request, 'store/blog.html')

# Contact View
def contact_view(request):
    return render(request, 'store/contact.html')

# Handle Contact Submission
def submit_contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        # Add your logic to handle the data here
        return redirect('store:success')
    return HttpResponse("Invalid request", status=400)

# Success View
def success_view(request):
    return render(request, 'store/success.html')

# Product Detail View
def detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    related_products = Product.objects.exclude(id=product.id).filter(is_active=True, category=product.category)
    context = {
        'product': product,
        'related_products': related_products,
    }
    return render(request, 'store/detail.html', context)

# All Categories View
def all_categories(request):
    categories = Category.objects.filter(is_active=True)
    return render(request, 'store/categories.html', {'categories': categories})

# Category Products View
def category_products(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = Product.objects.filter(is_active=True, category=category)
    context = {
        'category': category,
        'products': products,
    }
    return render(request, 'store/category_products.html', context)

# User Registration View (Class-based)
class RegistrationView(View):
    def get(self, request):
        form = RegistrationForm()
        return render(request, 'account/register.html', {'form': form})

    def post(self, request):
        form = RegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, "Congratulations! Registration Successful!")
            form.save()
        return render(request, 'account/register.html', {'form': form})

# User Profile View
@login_required
def profile(request):
    addresses = Address.objects.filter(user=request.user)
    orders = Order.objects.filter(user=request.user)
    return render(request, 'account/profile.html', {'addresses': addresses, 'orders': orders})

# Address Management View (Class-based)
@method_decorator(login_required, name='dispatch')
class AddressView(View):
    def get(self, request):
        form = AddressForm()
        return render(request, 'account/add_address.html', {'form': form})

    def post(self, request):
        form = AddressForm(request.POST)
        if form.is_valid():
            user = request.user
            reg = Address(
                user=user,
                locality=form.cleaned_data['locality'],
                city=form.cleaned_data['city'],
                state=form.cleaned_data['state'],
            )
            reg.save()
            messages.success(request, "New Address Added Successfully.")
        return redirect('store:profile')

# Remove Address
@login_required
def remove_address(request, id):
    a = get_object_or_404(Address, user=request.user, id=id)
    a.delete()
    messages.success(request, "Address removed.")
    return redirect('store:profile')

# Add to Cart
@login_required
def add_to_cart(request):
    user = request.user
    product_id = request.GET.get('prod_id')
    product = get_object_or_404(Product, id=product_id)
    item_already_in_cart = Cart.objects.filter(product=product_id, user=user)
    if item_already_in_cart.exists():
        cp = item_already_in_cart.first()
        cp.quantity += 1
        cp.save()
    else:
        Cart(user=user, product=product).save()
    return redirect('store:cart')

# Cart View
@login_required
def cart(request):
    user = request.user
    cart_products = Cart.objects.filter(user=user)
    amount = sum(p.quantity * p.product.price for p in cart_products)
    shipping_amount = decimal.Decimal(10)
    total_amount = amount + shipping_amount
    addresses = Address.objects.filter(user=user)
    context = {
        'cart_products': cart_products,
        'amount': amount,
        'shipping_amount': shipping_amount,
        'total_amount': total_amount,
        'addresses': addresses,
    }
    return render(request, 'store/cart.html', context)

# Remove Cart Item
@login_required
def remove_cart(request, cart_id):
    c = get_object_or_404(Cart, id=cart_id)
    c.delete()
    messages.success(request, "Product removed from Cart.")
    return redirect('store:cart')

# Increment Cart Item Quantity
@login_required
def plus_cart(request, cart_id):
    cp = get_object_or_404(Cart, id=cart_id)
    cp.quantity += 1
    cp.save()
    return redirect('store:cart')

# Decrement Cart Item Quantity
@login_required
def minus_cart(request, cart_id):
    cp = get_object_or_404(Cart, id=cart_id)
    if cp.quantity == 1:
        cp.delete()
    else:
        cp.quantity -= 1
        cp.save()
    return redirect('store:cart')

# Checkout View
@login_required
def checkout(request):
    user = request.user
    address_id = request.GET.get('address')
    address = get_object_or_404(Address, id=address_id)
    cart_items = Cart.objects.filter(user=user)
    for item in cart_items:
        Order(user=user, address=address, product=item.product, quantity=item.quantity).save()
        item.delete()
    return redirect('store:orders')

# Orders View
@login_required
def orders(request):
    all_orders = Order.objects.filter(user=request.user).order_by('-ordered_date')
    return render(request, 'store/orders.html', {'orders': all_orders})

# Shop View
def shop(request):
    return render(request, 'store/shop.html')

# Test View
def test(request):
    return render(request, 'store/test.html')

    
